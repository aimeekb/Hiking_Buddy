-- Project Group 26, Step 2 Draft
-- Team members: Aimee Bogle & Gunars Turaids

SET FOREIGN_KEY_CHECKS=0;
SET AUTOCOMMIT = 0;
-- Create DB table structure 

CREATE TABLE Users (
    idUser INT NOT NULL AUTO_INCREMENT,
    email varchar(45),
    first_name varchar(45) NOT NULL,
    last_name varchar(45) NOT NULL,
    user_location varchar(45),
    user_miles decimal,
    PRIMARY KEY (idUser)
);

CREATE TABLE Trail_types (
    idTrail_type INT NOT NULL AUTO_INCREMENT,
    trail_type_description varchar(45) NOT NULL,
    PRIMARY KEY (idTrail_type)
);

CREATE TABLE Trails (
    idTrail INT NOT NULL AUTO_INCREMENT,
    Trail_types_idTrail_type INT NOT NULL,
    trail_name varchar(45) NOT NULL,
    trail_location varchar(45) NOT NULL,
    trail_miles DECIMAL (5,1) NOT NULL,
    PRIMARY KEY (idTrail),
    FOREIGN KEY (Trail_types_idTrail_type) REFERENCES Trail_types(idTrail_type)
);

CREATE TABLE Inventory_items (
    idItem INT NOT NULL AUTO_INCREMENT,
    item_name varchar(45) NOT NULL,
    item_description varchar(45) NOT NULL,
    item_weight DECIMAL (3,1) NOT NULL,
    PRIMARY KEY (idItem)
);

CREATE TABLE Packing_lists (
    idPacking_list INT NOT NULL AUTO_INCREMENT,
    Trail_Types_idTrail_type INT NOT NULL,
    PRIMARY KEY (idPacking_list),
    FOREIGN KEY (Trail_types_idTrail_type) REFERENCES Trail_types(idTrail_type)
);

CREATE TABLE Packing_list_details(
    idPacking_list_details INT NOT NULL AUTO_INCREMENT,
    Inventory_items_idItem INT NOT NULL,
    Packing_lists_idPacking_list INT NOT NULL,
    PRIMARY KEY (idPacking_list_details),
    CONSTRAINT FK_Packing_list_details_Inventory_items_idItem FOREIGN KEY (Inventory_items_idItem)
        REFERENCES Inventory_items(idItem),
    CONSTRAINT FK_Packing_list_details_Packing_lists_idPacking_list FOREIGN KEY (Packing_lists_idPacking_list)
        REFERENCES Packing_lists(idPacking_list)
);

CREATE TABLE Hikes(
    idHike INT NOT NULL AUTO_INCREMENT,
    Users_idUser INT NOT NULL,
    Trails_idTrail INT NOT NULL,
    Packing_lists_idPacking_list INT NOT NULL,
    hike_date DATE,
    PRIMARY KEY (idHike),
    FOREIGN KEY (Users_idUser) REFERENCES Users(idUser),
    FOREIGN KEY (Trails_idTrail) REFERENCES Trails(idTrail),
    FOREIGN KEY (Packing_lists_idPacking_list) REFERENCES Packing_lists(idPacking_list)
);

-- Insert sample data 

INSERT INTO Users (
    email,
    first_name,
    last_name,
    user_location,
    user_miles
)
VALUES 
(
    "SammyJ@email.com",
    "Sammy",
    "Jones",
    "Seattle",
    0
),
(
    "JaneyJaneJane@email.com",
    "Jane",
    "McJones",
    "Reno",
    0
),
(
    "SmoothEd@email.com",
    "Eddie",
    "Reinquist",
    "Los Angeles",
    0
);

INSERT INTO Trail_types (
    trail_type_description
)
VALUES 
(
    "Mountainous-Day"
),
(
    "Mountainous-Multi Day"
),
(
    "Arid-Day"
),
(
    "Arid-Multi Day"
),
(
    "Long Distance"
);

INSERT INTO Trails (
    Trail_types_idTrail_type,
    trail_name,
    trail_location,
    trail_miles
)
VALUES 
(
    1,
    "Hurrican Ridge",
    "Olympic National Park",
    11.4
),
(
    2,
    "John Muir Trail",
    "Sierra Nevada",
    211.7
),
(
    5,
    "Pacific Crest Trail",
    "West Coast USA",
    2665.8
),
(
    2,
    "West Coast Trail",
    "Vancouver Island",
    46.6
),
(
    1,
    "Half Dome",
    "Yosemite National Park",
    15.0
);

INSERT INTO Inventory_items (
    item_name,
    item_description,
    item_weight
)
VALUES 
(
    "Osprey Exos 58",
    "UL pack. 58 liters",
    2.60
),
(
    "Big Agnes Fly Creek UL2",
    "UL, 2 person tent",
    2.13
),
(
    "NeoAir XTherm MAX",
    "Sleeping pad: 6.9 R-Value",
    1.08
),
(
    "North Face FutureLite Boots",
    "Hiking Boots",
    0.9
),
(
    "Arcteryx Atom AR Hoody",
    "Ultralite rain jacket",
    1.6
);

INSERT INTO Packing_lists (
    idPacking_list,
    Trail_Types_idTrail_type
)
VALUES 
(
    '1',
    '1'
),
(
    '4',
    '2'
),
(
    '2',
    '4'
),
(
    '3',
    '4'
);

INSERT INTO Packing_list_details (
    idPacking_list_details,
    Inventory_items_idItem,
    Packing_lists_idPacking_list
)
VALUES 
(
    '1',
    '1',
    '3'
),
(
    '2',
    '3',
    '1'
),
(
    '3',
    '2',
    '3'
),
(
    '4',
    '1',
    '4'
);

INSERT INTO Hikes (

    Users_idUser,
    Trails_idTrail,
    Packing_lists_idPacking_list,
    hike_date
)
VALUES 
(
    '2',
    '1',
    '2',
    '2022-07-11'
),
(
    '1',
    '2',
    '3',
    '2022-04-02'
),
(
    '3',
    '4',
    '1',
    '2022-05-14'
),
(
    '1',
    '5',
    '4',
    '2022-03-14'
);

SET FOREIGN_KEY_CHECKS=1;
COMMIT;