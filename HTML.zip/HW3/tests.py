from credit_card_validator import credit_card_validator
import random
import unittest


class TestCase(unittest.TestCase):
    pass

    # valid mastercard number, prefix 51-55
    def test1_mastercard(self):
        minimum = (5100000000000000)
        maximum = (5599999999999999)

        for i in range(0, 10000):
            mc_rand = random.randint(minimum, maximum)
            mc_num = str(mc_rand)
            credit_card_validator(mc_num)

    # valid mastercard number, prefix 2221-2720
    def test2_mc_prefix(self):
        minimum = (2221000000000000)
        maximum = (2720999999999999)

        for i in range(0, 10000):
            mc_rand = random.randint(minimum, maximum)
            mc_num = str(mc_rand)
            credit_card_validator(mc_num)

    # valid visa number, prefix 4
    def test3_visa(self):
        minimum = (4000000000000000)
        maximum = (4999999999999999)

        for i in range(0, 10000):
            visa_rand = random.randint(minimum, maximum)
            visa_num = str(visa_rand)
            credit_card_validator(visa_num)

    # valid american express number, prefix 34-37
    def test4_amerEx(self):
        minimum = (340000000000000)
        maximum = (379999999999999)

        for i in range(0, 10000):
            amerEx_rand = random.randint(minimum, maximum)
            amerEx_num = str(amerEx_rand)
            credit_card_validator(amerEx_num)

    # mastercard prefix 51-55 short length
    def test5_short_mc(self):
        minimum = (51000000000000)
        maximum = (55999999999999)

        for i in range(0, 10000):
            short_mc_rand = random.randint(minimum, maximum)
            short_mc_num = str(short_mc_rand)
            credit_card_validator(short_mc_num)

    # mastercard prefix 2221-2720 short length
    def test6_short_mc(self):
        minimum = (22210000000000)
        maximum = (27209999999999)

        for i in range(0, 10000):
            short_mc_rand = random.randint(minimum, maximum)
            short_mc_num = str(short_mc_rand)
            credit_card_validator(short_mc_num)

    # mastercard prefix 51-55 long length
    def test7_long_mc(self):
        minimum = (5100000000000000)
        maximum = (5599999999999999)

        for i in range(0, 10000):
            long_mc_rand = random.randint(minimum, maximum)
            long_mc_num = str(long_mc_rand)
            credit_card_validator(long_mc_num)

    # mastercard prefix 2221-2720 long length
    def test8_long_mc(self):
        minimum = (2221000000000000)
        maximum = (2720999999999999)

        for i in range(0, 10000):
            long_mc_rand = random.randint(minimum, maximum)
            long_mc_num = str(long_mc_rand)
            credit_card_validator(long_mc_num)

    # visa prefix, short length
    def test9_short_visa(self):
        minimum = (400000000000000)
        maximum = (499999999999999)

        for i in range(0, 10000):
            visa_rand = random.randint(minimum, maximum)
            visa_num = str(visa_rand)
            credit_card_validator(visa_num)

    # visa prefix, long length
    def test10_long_visa(self):
        minimum = (40000000000000000)
        maximum = (49999999999999999)

        for i in range(0, 10000):
            visa_rand = random.randint(minimum, maximum)
            visa_num = str(visa_rand)
            credit_card_validator(visa_num)

    # american express prefix, short length
    def test11_short_amerEx(self):
        minimum = (34000000000000)
        maximum = (37999999999999)

        for i in range(0, 10000):
            amerEx_rand = random.randint(minimum, maximum)
            amerEx_num = str(amerEx_rand)
            credit_card_validator(amerEx_num)

    # american express prefix, long length
    def test12_long_amerEx(self):
        minimum = (3400000000000000)
        maximum = (3799999999999999)

        for i in range(0, 10000):
            amerEx_rand = random.randint(minimum, maximum)
            amerEx_num = str(amerEx_rand)
            credit_card_validator(amerEx_num)

    # any prefix from 0-5 for length 16
    def test13_rand_16(self):
        minimum = (0000000000000000)
        maximum = (5999999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # any prefix from 6-9 for length 16
    def test14_rand_16(self):
        minimum = (6000000000000000)
        maximum = (9999999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # any prefix from 0-5 for length 15
    def test15_rand_15(self):
        minimum = (000000000000000)
        maximum = (599999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # any prefix from 6-9 for length 15
    def test16_rand_15(self):
        minimum = (600000000000000)
        maximum = (999999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # any prefix from 0-9 for length 14
    def test17_rand_short(self):
        minimum = (00000000000000)
        maximum = (99999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # any prefix from 0-9 for length 17
    def test18_rand_long(self):
        minimum = (00000000000000000)
        maximum = (99999999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)

        # empty string test
    def test19_empty(self):
        num = ''
        credit_card_validator(num)

        # any number length range 10-19 digits
    def test20_rand_length(self):
        minimum = (0000000000)
        maximum = (9999999999999999999)

        for i in range(0, 10000):
            rand = random.randint(minimum, maximum)
            num = str(rand)
            credit_card_validator(num)


if __name__ == '__main__':
    unittest.main()
