import random
import string 

def credit_card_validator():
    pass


# def randomnumber():
# 	minimum = (4000000000000000)
# 	maximum = (4999999999999999)
# 	return random.randint(minimum, maximum)

# rand = randomnumber()

# print(rand)

def test1_mastercard():
    minimum = (4000000000000000)
    maximum = (4999999999999999)
     
    for i in range(0, 6):
        mc_num = random.randint(minimum, maximum)
        print(mc_num)

num = test1_mastercard()

convert_num = str(num)
print(convert_num)
print(type(convert_num))